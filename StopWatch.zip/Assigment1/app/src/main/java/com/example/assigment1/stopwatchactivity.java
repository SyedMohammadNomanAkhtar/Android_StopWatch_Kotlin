package com.example.assigment1;

import android.app.Activity;

public class stopwatchactivity extends Activity {

}
